from django.apps import AppConfig


class GuiasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'guias'
